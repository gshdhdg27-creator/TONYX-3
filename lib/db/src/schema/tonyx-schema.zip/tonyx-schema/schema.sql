-- Server-authoritative boss / mage economy.
-- Safe to run more than once (IF NOT EXISTS).

CREATE TABLE IF NOT EXISTS mini_user_mages (
  id serial PRIMARY KEY,
  telegram_id text NOT NULL,
  mage_id text NOT NULL,
  level integer NOT NULL DEFAULT 1,
  created_at timestamp NOT NULL DEFAULT now(),
  updated_at timestamp NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS mini_user_mages_telegram_mage_uidx
  ON mini_user_mages (telegram_id, mage_id);

CREATE TABLE IF NOT EXISTS mini_user_loadout (
  id serial PRIMARY KEY,
  telegram_id text NOT NULL UNIQUE,
  equipped_slots jsonb NOT NULL DEFAULT '[null,null,null,null,null]'::jsonb,
  updated_at timestamp NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS mini_user_boss_state (
  id serial PRIMARY KEY,
  telegram_id text NOT NULL,
  boss_level integer NOT NULL,
  respawn_at timestamp,
  revive_ads_watched integer NOT NULL DEFAULT 0,
  updated_at timestamp NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS mini_user_boss_state_uidx
  ON mini_user_boss_state (telegram_id, boss_level);

CREATE TABLE IF NOT EXISTS mini_battles (
  id serial PRIMARY KEY,
  telegram_id text NOT NULL,
  boss_level integer NOT NULL,
  equipped_mage_ids jsonb NOT NULL DEFAULT '[]'::jsonb,
  total_dps_snapshot numeric(18, 6) NOT NULL,
  status text NOT NULL DEFAULT 'active',
  rewards jsonb,
  started_at timestamp NOT NULL DEFAULT now(),
  claimed_at timestamp,
  expired_at timestamp
);

CREATE TABLE IF NOT EXISTS mini_nft_inventory (
  id serial PRIMARY KEY,
  telegram_id text NOT NULL UNIQUE,
  fragments jsonb NOT NULL DEFAULT '{}'::jsonb,
  assembled jsonb NOT NULL DEFAULT '[]'::jsonb,
  collections jsonb NOT NULL DEFAULT '{}'::jsonb,
  updated_at timestamp NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS mini_user_battle_boosts (
  id serial PRIMARY KEY,
  telegram_id text NOT NULL UNIQUE,
  ad_watched_count integer NOT NULL DEFAULT 0,
  dps_multiplier numeric(6, 3) NOT NULL DEFAULT 1.000,
  boost_expires_at timestamp,
  ton_boost_multiplier numeric(6, 3) NOT NULL DEFAULT 1.000,
  ton_boost_expires_at timestamp,
  speed_multiplier numeric(6, 3) NOT NULL DEFAULT 1.000,
  updated_at timestamp NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS mini_user_boss_keys (
  id serial PRIMARY KEY,
  telegram_id text NOT NULL,
  boss_level integer NOT NULL,
  keys_count integer NOT NULL DEFAULT 0,
  updated_at timestamp NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS mini_user_boss_keys_uidx
  ON mini_user_boss_keys (telegram_id, boss_level);
