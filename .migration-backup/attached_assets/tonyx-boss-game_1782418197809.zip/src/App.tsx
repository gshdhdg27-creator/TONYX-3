import { useEffect } from "react";
import { useGameStore } from "./store/gameStore";
import HomeScreen from "./components/HomeScreen";
import BattleScreen from "./components/battle/BattleScreen";
import ChestScreen from "./components/chest/ChestScreen";
import CollectionScreen from "./components/collection/CollectionScreen";
import LoadingScreen from "./components/ui/LoadingScreen";
import "./styles/global.css";

export default function App() {
  const view = useGameStore((s) => s.view);
  const init = useGameStore((s) => s.init);

  useEffect(() => {
    const t = setTimeout(() => init(), 800);
    return () => clearTimeout(t);
  }, [init]);

  return (
    <div className="app-root">
      {view === "loading" && <LoadingScreen />}
      {view === "home" && <HomeScreen />}
      {view === "battle" && <BattleScreen />}
      {view === "chest" && <ChestScreen />}
      {view === "collection" && <CollectionScreen />}
    </div>
  );
}
