import { useState } from "react";
import { useTelegram } from "@/lib/telegram";
import { useLang } from "@/lib/LanguageContext";
import MinesGame from "@/components/MinesGame";

type Tab = "mines" | "coin" | "roulette";

export default function SoloPage() {
  const { telegramId } = useTelegram();
  const { lang } = useLang();
  const [tab, setTab] = useState<Tab>("mines");
  const [tonBalance, setTonBalance] = useState(0);

  return (
    <div style={{ minHeight: "100dvh", padding: "12px 12px 110px", color: "#f1f5f9", fontFamily: "'Space Grotesk','Inter',system-ui,sans-serif" }}>
      <div style={{ display: "flex", gap: 8, marginBottom: 12 }}>
        <TabButton on={tab === "mines"} label="Mines" onClick={() => setTab("mines")} />
        <TabButton on={tab === "coin"} label="Монетка" onClick={() => setTab("coin")} />
        <TabButton on={tab === "roulette"} label="Рулетка" onClick={() => setTab("roulette")} />
      </div>
      {tab === "mines" ? (
        <MinesGame
          telegramId={telegramId ?? ""}
          balance={tonBalance}
          lang={lang}
          onBalanceChange={setTonBalance}
        />
      ) : (
        <Stub title={tab === "coin" ? "Монетка" : "Рулетка"} />
      )}
    </div>
  );
}

function Stub({ title }: { title: string }) {
  return (
    <div style={{
      borderRadius: 16,
      padding: 20,
      background: "rgba(15,23,42,0.8)",
      border: "1px solid rgba(30,58,143,0.35)",
    }}>
      <div style={{ fontSize: 18, fontWeight: 800, marginBottom: 6 }}>{title}</div>
      <div style={{ fontSize: 13, color: "#94a3b8", lineHeight: 1.5 }}>
        Заглушка. Игра появится после меню, на шаге мини-игр.
      </div>
    </div>
  );
}

function TabButton({ on, label, onClick }: { on: boolean; label: string; onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      style={{
        flex: 1,
        height: 36,
        borderRadius: 10,
        border: on ? "1px solid #60a5fa" : "1px solid rgba(51,65,85,0.8)",
        background: on ? "rgba(37,99,235,0.25)" : "transparent",
        color: on ? "#bfdbfe" : "#94a3b8",
        fontWeight: 800,
        fontSize: 12,
      }}
    >
      {label}
    </button>
  );
}
