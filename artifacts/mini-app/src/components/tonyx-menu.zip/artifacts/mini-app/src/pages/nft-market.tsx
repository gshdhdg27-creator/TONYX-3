export default function NftMarketPage() {
  return (
    <div style={{
      minHeight: "100dvh",
      padding: "24px 16px 110px",
      color: "#f1f5f9",
      fontFamily: "'Space Grotesk','Inter',system-ui,sans-serif",
    }}>
      <div style={{ fontSize: 22, fontWeight: 900, marginBottom: 16 }}>NFT Market</div>
      <div style={{
        borderRadius: 16,
        padding: 20,
        background: "rgba(15,23,42,0.8)",
        border: "1px solid rgba(30,58,143,0.35)",
      }}>
        <div style={{ fontSize: 28, marginBottom: 8 }}>🖼</div>
        <div style={{ fontSize: 16, fontWeight: 800, marginBottom: 6 }}>Скоро</div>
        <div style={{ fontSize: 13, color: "#94a3b8", lineHeight: 1.5 }}>
          Витрина в стиле Portal. Покупка и продажа NFT за TON появятся следующим шагом.
        </div>
      </div>
    </div>
  );
}
