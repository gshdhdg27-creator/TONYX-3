Куда класть
-----------
Файлы из lib/db/src/schema/ положи в lib/db/src/schema/ проекта TONYX-3
(создай, если файла нет; index.ts — замени целиком).

Потом в корне проекта:
  pnpm --filter @workspace/db run push

Если push нет — выполни schema.sql в PostgreSQL.
