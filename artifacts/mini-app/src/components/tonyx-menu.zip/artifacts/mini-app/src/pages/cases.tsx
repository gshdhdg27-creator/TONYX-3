import { useState } from "react";
import { useTelegram } from "@/lib/telegram";
import { useLang } from "@/lib/LanguageContext";
import CasesGame from "@/components/CasesGame";

export default function CasesPage() {
  const { lang } = useLang();
  const [tick, setTick] = useState(0);
  return (
    <div style={{ minHeight: "100dvh", paddingBottom: 110 }}>
      <CasesGame lang={lang} onBalanceChange={() => setTick((n) => n + 1)} />
      <span style={{ display: "none" }}>{tick}</span>
    </div>
  );
}
