import HomeScreen from "@/components/HomeScreen";

export default function BossesPage() {
  return (
    <div style={{ minHeight: "100dvh", paddingBottom: 110 }}>
      <HomeScreen />
    </div>
  );
}
