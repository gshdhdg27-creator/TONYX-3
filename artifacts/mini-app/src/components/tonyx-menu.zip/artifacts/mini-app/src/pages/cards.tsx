import HeroShopScreen from "@/components/hero-shop/HeroShopScreen";

export default function CardsPage() {
  return (
    <div style={{ minHeight: "100dvh", paddingBottom: 110 }}>
      <HeroShopScreen />
    </div>
  );
}
