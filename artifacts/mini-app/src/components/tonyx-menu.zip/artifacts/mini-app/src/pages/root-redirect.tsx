import { useEffect } from "react";
import { useLocation } from "wouter";

/** Главной больше нет. Старый адрес / открывает Market. */
export default function RootRedirect() {
  const [, setLocation] = useLocation();
  useEffect(() => {
    setLocation("/market");
  }, [setLocation]);
  return null;
}
