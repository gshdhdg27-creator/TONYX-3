import { useState } from "react";
import { useTelegram } from "@/lib/telegram";
import ArenaGame from "@/components/ArenaGame";
import SpinGame from "@/components/SpinGame";

type Tab = "arena" | "spin";

export default function PvpPage() {
  const { telegramId } = useTelegram();
  const [tab, setTab] = useState<Tab>("arena");
  const [tonBalance, setTonBalance] = useState(0);

  return (
    <div style={{ minHeight: "100dvh", padding: "12px 12px 110px", color: "#f1f5f9" }}>
      <div style={{ display: "flex", gap: 8, marginBottom: 12 }}>
        <TabButton on={tab === "arena"} label="Арена" onClick={() => setTab("arena")} />
        <TabButton on={tab === "spin"} label="Барабан" onClick={() => setTab("spin")} />
      </div>
      {tab === "arena" ? (
        <ArenaGame
          telegramId={telegramId ?? ""}
          tonBalance={tonBalance}
          onBalanceChange={setTonBalance}
          onClose={() => setTab("arena")}
          onOpenHistory={() => undefined}
        />
      ) : (
        <SpinGame
          telegramId={telegramId ?? ""}
          tonBalance={tonBalance}
          onBalanceChange={setTonBalance}
          onOpenHistory={() => undefined}
        />
      )}
    </div>
  );
}

function TabButton({ on, label, onClick }: { on: boolean; label: string; onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      style={{
        flex: 1,
        height: 36,
        borderRadius: 10,
        border: on ? "1px solid #60a5fa" : "1px solid rgba(51,65,85,0.8)",
        background: on ? "rgba(37,99,235,0.25)" : "transparent",
        color: on ? "#bfdbfe" : "#94a3b8",
        fontWeight: 800,
      }}
    >
      {label}
    </button>
  );
}
