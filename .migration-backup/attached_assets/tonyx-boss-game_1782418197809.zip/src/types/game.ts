// ─── VIEW ──────────────────────────────────────────────
export type ViewName = "loading" | "home" | "battle" | "chest" | "collection";

// ─── BOSS ──────────────────────────────────────────────
export type BossLevel = 1 | 2 | 3 | 4 | 5;

export type BossAnimState =
  | "idle"
  | "rage"
  | "roar"
  | "stomp"
  | "fire_breath";

export interface BossConfig {
  level: BossLevel;
  name: string;
  maxHp: number;
  baseAttack: number; // урон по герою в секунду
  attackInterval: [number, number]; // [min, max] секунд
  rewardTon: number;
  rewardTonyx: number;
  color: string; // акцентный цвет уровня
}

// ─── MAGE ──────────────────────────────────────────────
export type MageType = "fire" | "ice" | "lightning" | "wind";

export interface MageConfig {
  id: string;
  name: string;
  type: MageType;
  baseDps: number; // урон в секунду
  upgradeCost: number; // TONYX
  level: number;
  emoji: string;
  attackColor: string;
}

export interface OwnedMage extends MageConfig {
  level: number;
}

// ─── NFT ───────────────────────────────────────────────
export type NftId = "shadow_dogg" | "flame_dogg" | "ice_dogg";

export interface NftConfig {
  id: NftId;
  name: string;
  description: string;
  emoji: string;
  totalFragments: 9;
}

export interface NFTInventory {
  fragments: Record<NftId, number>; // 0–9
  assembled: NftId[];               // собранные NFT
}

// ─── CHEST ─────────────────────────────────────────────
export type ChestRewardType = "ton" | "tonyx" | "nft_fragment" | "nft_full";

export interface ChestReward {
  type: ChestRewardType;
  amount?: number;
  nftId?: NftId;
  fragmentNftId?: NftId;
}

// ─── BATTLE ────────────────────────────────────────────
export interface BattleState {
  active: boolean;
  bossHpPercent: number;        // 0–100
  heroHp: number;               // 0–100
  totalDps: number;             // кешированный суммарный DPS
  lastRewards: ChestReward[] | null;
}

// ─── BOOST ─────────────────────────────────────────────
export interface BoostState {
  dpsMultiplier: number;        // 1.0 | 1.2 (после 10 реклам)
  adWatchedCount: number;       // счётчик реклам (сброс 24ч)
  boostExpiresAt: number | null; // timestamp
  speedMultiplier: number;      // 1 | 2
}

// ─── ROOT GAME STATE ───────────────────────────────────
export interface GameState {
  // навигация
  view: ViewName;

  // балансы
  balances: {
    ton: number;
    tonyx: number;
  };

  // выбор босса
  selectedBossLevel: BossLevel;

  // боевой стейт
  battle: BattleState;

  // маги — у игрока (макс 5 в бою)
  ownedMages: OwnedMage[];
  activeMageIds: string[]; // max 5

  // NFT инвентарь
  nftInventory: NFTInventory;

  // буст
  boost: BoostState;
}
