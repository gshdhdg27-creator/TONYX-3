import CollectionScreen from "@/components/collection/CollectionScreen";

export default function CollectionPage() {
  return (
    <div style={{ minHeight: "100dvh", paddingBottom: 110 }}>
      <CollectionScreen />
    </div>
  );
}
